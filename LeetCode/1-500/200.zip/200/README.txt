This is my solution to a leetcode problem. It used a breadth first search (recursion) to solve the problem, of how many "islands" of the number 1 are in a two dimensional array.

The three key parts to using recursion, are a base case to identify when the problem has been solved, the recursive call, and simplyifying the problem before the recursive call. 